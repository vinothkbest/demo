<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php wp_head(); ?>
</head>
<script src="https://www.google.com/recaptcha/api.js?" async defer></script>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header style="background-image: url(<?php echo get_theme_file_uri(). "/images/poster/head.png";?>);">

	<div class="container">
		<div class="header-panel">

		<section class="head-icon-menu">
			<div class="icon">
				<img class="icon" src="<?php echo get_site_icon_url(); /* @description Loading the logo from wordpress site Icon */ ?>" width="150px" height="150px">
			</div>
			<div class="head-menu" style="width:80%; margin-right: 15px;" align="right">
				<i class="menu-open-close fa fa-bar" style="color: white;"></i>
			    <nav class="menu-links">
					<?php 
					       echo wp_nav_menu(array('theme_location'=>'header',
	                                        	  'container' =>'',
	                                       		  'container_class' => '')); /* eader menu call by theme location header*/
	                ?>
			    </nav>
			</div>
		</section>

		<section class="head-content">
				<div class="content-box">
				  <p>build your website</p>
				  <p>Effortlessly</p>
				  <p>we are simple builder, your new business parner</p>
				</div>
		</section>
		</div> 
	</div>	
		
</header><!-- #masthead -->
