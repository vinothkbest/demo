<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */

?>


<footer>
<div class="footer">
	<section class="text-panel">
		<div class="container text-header">
			<p class="text-learn">Donec viverra eleifend blandit. Mauris feugiat ultrices tellus, non malesuada velit dapibus.
			<i class="fa fa-arrow-circle-o-right" aria-hidden="true" style="font-size: 18px;"></i>
			</p>
		</div>
	</section>
	<section class="form-about-panel">
		<div class="container">
			<form class="contact" action="" method="post">
				<div class="form-panel">
					<div class="inputs">
						<input type="text" name="username" class="username" placeholder="name" style="margin-top:50px">
						<input type="text" name="email" class="emai" placeholder="email">
					</div>
					<textarea class="message" placeholder="message"></textarea>
					<div class="recaptcha">
						<div class="g-recaptcha" data-size="compact normal" data-sitekey="6LecFd4ZAAAAAP05ddSFfulmJ8PNV28GgQo09J85"></div>
					</div>
					<input type="submit" name="submit" value="SUBMIT YOUR MESSAGE">
				</div>
			</form>
			<div class="about-us" style="color: white;">
				<h4 style="text-transform: uppercase; margin-top: 50px;">About Us</h4>
				<p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et Malorum for use in a type specimen book.</p>
			</div>
		</div>
	</section>
</div>
</footer>
<?php wp_footer(); ?>

</body>
</html>
