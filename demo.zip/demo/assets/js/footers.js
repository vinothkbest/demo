$(document).ready(function(){
	var scrollLoad = true;
	$(window).on('scroll', function() {
		var height = $('.work-with-us2-panel, .work-with-us1-panel, footer').height()+600;
		if(scrollLoad && $(this).scrollTop() + $(this).height() > $(document).height() - height) {
			var more_sales = document.getElementById('more-sales').getContext('2d');
			var new_sales= document.getElementById('new-sales').getContext('2d');
			var conversion = document.getElementById('conversion').getContext('2d');
			var a=0, b=0, c=0, start=5, start_new_sales=6, diff;
			var cw=more_sales.canvas.width/2;
			var ch=more_sales.canvas.height/2;

			function more_sales_progress(){
				diff=(a/100)*Math.PI*2;
				more_sales.clearRect(0,0,400,200);
				more_sales.beginPath();
				more_sales.arc(cw,ch,75,0,2*Math.PI,false);
				more_sales.strokeStyle='white';
				more_sales.stroke();
				more_sales.fillStyle='white';
				more_sales.strokeStyle='black';
				more_sales.textAlign='center';
				more_sales.lineWidth=10;
				more_sales.font = '18pt times';
				more_sales.beginPath();
				more_sales.arc(cw,ch,75,start,diff+start,false);
				more_sales.stroke();
				more_sales.fillText(a+'%',cw+2,ch+6);
				if(a>=68){
				clearTimeout(more_sales_bar);
				scrollLoad = false;}
				a = a+1;
			}

			var more_sales_bar=setInterval(more_sales_progress,50);

			function new_sales_progress(){
				diff=(b/100)*Math.PI*2;
				new_sales.clearRect(0,0,400,200);
				new_sales.beginPath();
				new_sales.arc(cw,ch,75,0,2*Math.PI,false);
				new_sales.strokeStyle='white';
				new_sales.stroke();
				new_sales.fillStyle='white';
				new_sales.strokeStyle='black';
				new_sales.textAlign='center';
				new_sales.lineWidth=10;
				new_sales.font = '18pt times';
				new_sales.beginPath();
				new_sales.arc(cw,ch,75,start_new_sales,diff+start_new_sales,false);
				new_sales.stroke();
				new_sales.fillText(b+'%',cw+2,ch+6);
				if(b>=37){
				clearTimeout(new_sales_bar);
				scrollLoad = false;}
			    b= b+1;
			}

			var new_sales_bar=setInterval(new_sales_progress,50);

			function conversion_progress(){
				diff=(c/100)*Math.PI*2;
				conversion.clearRect(0,0,400,200);
				conversion.beginPath();
				conversion.arc(cw,ch,75,0,2*Math.PI,false);
				conversion.strokeStyle='white';
				conversion.stroke();
				conversion.fillStyle='white';
				conversion.strokeStyle='black';
				conversion.textAlign='center';
				conversion.lineWidth=10;
				conversion.font = '18pt times';
				conversion.beginPath();
				conversion.arc(cw,ch,75,start,diff+start,false);
				conversion.stroke();
				conversion.fillText(c+'%',cw+2,ch+6);
				if(c>=50){
				clearTimeout(conversion_bar);
				scrollLoad = false;}
			    c= c+1;
			}

			var conversion_bar=setInterval(conversion_progress,50);
			$(this).unbind('scroll');				

		}
	});
	

});

