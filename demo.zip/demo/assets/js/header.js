$(document).ready(function(){
		$('form').attr('autocomplete', 'off');
		$('#s').attr('placeholder', 'search text ...');
		$('.screen-reader-text, #searchsubmit').remove();

		$(window).resize(function(){
			if($(window).width >=768){
				$('.menu-links > .menu').attr('style', "display:flex;");
			}
		});
	
		let count = 0;
		$('.menu-open-close').on('click', function(){
			count = count+1;
			switch(count){
					case 1:
					      $('.menu-open-close').removeClass('fa-bars');
						  $('.menu-open-close').addClass('fa-times');
						  $('.nav-header').css({"display":"block"});
						  $('.menu-links > .menu').css({"display":"flex", "flex-direction":"column"});
						  $('.menu-links').css({"margin-left":"-150px", "margin-top":"45px"});
						  $('.sub-menu').css({"column-count":1});
						  break;
					case 2:
						  $('.menu-open-close').removeClass('fa-times');
					      $('.menu-open-close').addClass('fa-bars');
						  $('.nav-header, .menu-links > .menu').css({"display":"none"});
						  break;
				    default:
				          $('.menu-open-close').removeClass('fa-bars');
					      $('.menu-open-close').addClass('fa-times');
					      $('.nav-header').css({"display":"block"});
					      $('.menu-links > .menu').css({"display":"flex", "flex-direction":"column"});
					      $('.menu-links').css({"margin-left":"-150px", "margin-top":"45px"});;
					      $('.sub-menu').css({"column-count":1});
					      count = 1;
				          break;
			}
		});
});