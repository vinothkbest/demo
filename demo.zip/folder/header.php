<!DOCTYPE html>
<html>
<head>
	<title><?php echo 'Technolabs'; wp_title('|', true, 'left'); ?></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php wp_head();?>
</head>
<script src="https://www.google.com/recaptcha/api.js?" async defer></script>
<body>
	<header>
			<div class="container">
				<div class="header-nav">
				<div class="home-icon">
					<a href="http://localhost:8086/wordpress/"><img class="home-logo" src="<?php echo get_site_icon_url(); ?>"></a>
				</div>
				<div class="header-search-menu">
					<i class="fa fa-bars menu-open-close"></i>
					<div class="nav-header">
						<nav class="menu-links">
							<?php 
							       echo wp_nav_menu(array('theme_location'=>'header',
			                                        	  'container' =>'',
			                                       		  'container_class' => ''));
			                ?>
			            </nav>
					</div>
				</div>							
			</div>
			</div>
	</header>
